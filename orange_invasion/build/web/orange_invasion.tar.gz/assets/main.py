import asyncio
from random import randint
import pgzrun
import os

os.environ['SDL_VIDEO_CENTERED'] = '1'

WIDTH = 600
HEIGHT = 600

score = 0
vitesse_orange = 2
game_over = False
compt_heart = 0

orange = Actor("orange")
orange.pos = randint(10,550),0
    
cowboy = Actor("cowboy")
cowboy.pos = 300, 550

cowboy1 = Actor("cowboy_mort")
cowboy1.pos = 320, 530 

heart3 = Actor("heart3")
heart3.pos = 590, 20
heart3.active = True

heart2 = Actor("heart2")
heart2.pos = 560, 20
heart2.active = True

heart1 = Actor("heart1")
heart1.pos = 530, 20
heart1.active = True


bullet = Actor("bullet")
bullet.active = False



def reset_game ():
    global game_over,score,vitesse_orange
    score = 0
    game_over = False
    cowboy.pos = 300, 550
    orange.pos = randint(10,550),0
    vitesse_orange = 2

def draw ():
    screen.blit("background", (0, 0))
    
    if heart3.active :
        heart3.draw()
    if heart2.active :
        heart2.draw()
    if heart1.active :
        heart1.draw()
    
    cowboy.draw()
    orange.draw()
    screen.draw.text("Score: " + str(score), color="white", topleft=(10, 10))
    
    if bullet.active:
        bullet.draw()
    
    if game_over :
        screen.blit("background", (0, 0))
        screen.draw.text("Final Score: " + str(score), center=(300, 280), fontsize=60)
        screen.draw.text("Press R to restart ", color="white", center=(310, 330) )
        cowboy1.draw()
    
    
def update ():
    global score, vitesse_orange, game_over, compt_heart
    orange.y += vitesse_orange
    if orange.y > HEIGHT or orange.colliderect(cowboy):
        compt_heart += 1
        orange.pos = randint(10,550), 0
        if compt_heart == 1:
            heart3.active = False
        if compt_heart == 2:
            heart2.active = False
        if compt_heart == 3:
            heart1.active = False    
            #if not game_over:
            sounds.music.stop()
            sounds.game_over_sound.play()
            sounds.game_over.play()
            game_over = True
            
    if game_over:
        if keyboard.r:
            reset_game()
            sounds.game_over_sound.stop()
            sounds.game_over.stop()
            sounds.music.play(-1) 
        return        
    
    if keyboard.left:
        cowboy.x -= 7
    elif keyboard.right:
        cowboy.x += 7
        
    if cowboy.x < 20 :
        cowboy.x = 580
    elif cowboy.x > 580 :
        cowboy.x = 20
        
    if keyboard.space and not bullet.active and not game_over:
        sounds.shot.play()
        bullet.x = cowboy.x
        bullet.y = cowboy.y -20
        bullet.active = True    
    
    if bullet.active:
        bullet.y -= 10
        
    if bullet.y < 0:
        bullet.active = False
    elif bullet.colliderect(orange):
        vitesse_orange += 0.1
        score += 10
        bullet.active = False
        orange.pos = randint(10,550),0
   
    '''if score == 50:
        vitesse_orange = 2.5
    elif score == 90:
        vitesse_orange = 3
    elif score == 130:
        vitesse_orange = 3.5
    elif score == 170:
        vitesse_orange = 4
    elif score == 210 :
        vitesse_orange = 4.5'''



async def main():
    # On lance la musique ici, au démarrage de la fonction asynchrone
    try:
        sounds.music.play(-1)
    except:
        pass # Évite le crash si l'utilisateur n'a pas encore cliqué

    while True:
        # On ne met PAS pgzrun.go() ici, on laisse Pygbag gérer l'affichage
        await asyncio.sleep(0)

# Pygbag a besoin de pgzrun.go() MAIS il doit être appelé d'une manière spéciale
# pour que le moteur sache qu'il est sur le Web.
pgzrun.go()